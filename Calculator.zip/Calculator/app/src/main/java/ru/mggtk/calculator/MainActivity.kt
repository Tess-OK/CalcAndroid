package ru.mggtk.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var display: TextView
    private var currentNumber = ""
    private var operation = ""
    private var firstOperand = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.tvDisplay)

        val buttons = listOf(
            R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
            R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9
        )

        buttons.forEach { id ->
            findViewById<Button>(id).setOnClickListener { appendNumber((it as Button).text.toString()) }
        }

        findViewById<Button>(R.id.buttonAC).setOnClickListener { clear() }
        findViewById<Button>(R.id.buttonPlusMinus).setOnClickListener { toggleSign() }
        findViewById<Button>(R.id.buttonPercent).setOnClickListener { applyPercentage() }
        findViewById<Button>(R.id.buttonDivide).setOnClickListener { setOperation("÷") }
        findViewById<Button>(R.id.buttonMultiply).setOnClickListener { setOperation("×") }
        findViewById<Button>(R.id.buttonMinus).setOnClickListener { setOperation("−") }
        findViewById<Button>(R.id.buttonPlus).setOnClickListener { setOperation("+") }
        findViewById<Button>(R.id.buttonDot).setOnClickListener { appendDot() }
        findViewById<Button>(R.id.buttonEqual).setOnClickListener { calculate() }
    }

    private fun appendNumber(number: String) {
        currentNumber += number
        updateDisplay(currentNumber)
    }

    private fun appendDot() {
        if (!currentNumber.contains(".")) {
            currentNumber += "."
            updateDisplay(currentNumber)
        }
    }

    private fun clear() {
        currentNumber = ""
        operation = ""
        firstOperand = 0.0
        updateDisplay("0")
    }

    private fun toggleSign() {
        if (currentNumber.isNotEmpty()) {
            currentNumber = if (currentNumber.startsWith("-")) {
                currentNumber.substring(1)
            } else {
                "-$currentNumber"
            }
            updateDisplay(currentNumber)
        }
    }

    private fun applyPercentage() {
        if (currentNumber.isNotEmpty()) {
            currentNumber = (currentNumber.toDouble() / 100).toString()
            updateDisplay(currentNumber)
        }
    }

    private fun setOperation(op: String) {
        if (currentNumber.isNotEmpty()) {
            firstOperand = currentNumber.toDouble()
            currentNumber = ""
            operation = op
        }
    }

    private fun calculate() {
        if (currentNumber.isNotEmpty() && operation.isNotEmpty()) {
            val secondOperand = currentNumber.toDouble()
            val result = when (operation) {
                "÷" -> firstOperand / secondOperand
                "×" -> firstOperand * secondOperand
                "−" -> firstOperand - secondOperand
                "+" -> firstOperand + secondOperand
                else -> 0.0
            }
            currentNumber = result.toString()
            updateDisplay(currentNumber)
            operation = ""
        }
    }

    private fun updateDisplay(value: String) {
        display.text = value
    }
}